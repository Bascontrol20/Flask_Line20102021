#https://pypi.org/project/threaded/
from flask import Flask
from flask import request
from flask import render_template

from flask_sqlalchemy import SQLAlchemy

from flask_marshmallow import  Marshmallow

import json
import requests
import pymcprotocol #for PLC
import threading



#**************CONFIGURATIONS*******************
app = Flask(__name__)

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///Linenotify.sqlite3'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)
ma = Marshmallow(app)

#**************DATABASE*******************
class Linenotify(db.Model):

    id = db.Column(db.Integer,primary_key=True)
    linegroup = db.Column(db.String(100))
    plctag = db.Column(db.String(50))
    linemsg = db.Column(db.String(50))
    linetoken = db.Column(db.String(200))
    published = db.Column(db.DateTime)

    # def __repr__(self):
    #     return ("<LineGroup: {}>".format(self.linegroup),
    #             "<PLCTag: {}>".format(self.plctag),
    #             "<LineMessage: {}>".format(self.linemsg),
    #             "<LineToken: {}>".format(self.linetoken))
    def __init__(self,linegroup,plctag,linemsg,linetoken):
        self.linegroup = linegroup
        self.plctag = plctag
        self.linemsg = linemsg
        self.linetoken = linetoken
        #self.published = published

# class  LinenotifySchema(ma.Schema):
#     class Meta:
#         fields = ("linegroup","plctag","linemsg","linetoken","published")
#         ordering = ['plctag']
# linenotify_schema = LinenotifySchema()
# linenotifys_schema = LinenotifySchema(many=True)

#Use for create new database
#db.create_all()

@app.route("/",methods=["GET","POST"])
def home():
    
    if request.form:
        line_group =  request.form.get("line_group1")
        plc_tag = request.form.get("plc_tag1")
        line_msg = request.form.get("line_msg1")
        line_token =  request.form.get("line_token1")
        my_line = Linenotify(line_group,plc_tag,line_msg,line_token)
        db.session.add(my_line)
        db.session.commit()

    all_msg =  Linenotify.query.all()
    return render_template("msg_list.html", all_msgs = all_msg)

@app.route("/add",methods=["GET"])
def add_msg():
    return render_template("msg_add.html")


@app.route("/update",methods=["GET"])
def update_msg():
    return render_template("msg_edit.html")

@app.route("/delete/<int:id>" ,methods=["POST"])
def delete_msg():
    delete_msg =  Linenotify.query.filter_by(pk=id)
    delete_msg.delete()
    return render_template("msg_list.html")
# def mes_list(request):
#     all_msg = {'line_list': Linenotify.query.all()}
#     return render_template(request,"msg_list.html",all_msg)

# def plc_notify():
#     #threading.Timer(5.0,plc_notify).start()
#     print("PLC notify Running...")
#     # Set frame type
#     slmp = pymcprotocol.Type3E()
#     # Set PLC type
#     slmp = pymcprotocol.Type3E(plctype="iQ-R")
#     # Connect PLC
#     slmp.connect("192.168.0.104", 3000)
#     #get_url = "http://127.0.0.1:8000/api/?format=json"
#     #resp = requests.get(get_url)
#     #line_tokenget = Linenotify.query.get(id=1)

    
#     head_device = 'M10000'
#     device_batch_read = slmp.batchread_bitunits(headdevice=head_device, readsize=50)


    # '''MC01 M10000-M10009'''
    # #MessageNo.1
    # if device_batch_read[0] == 1:
    #     id= line_tokenget[0]['linetoken']
    #     msg1 = line_tokenget[0]['linemsg']
    #     line_notify(msg1,id)
    # #MessageNo.2
    # if device_batch_read[1] == 1:
    #     id= line_tokenget[1]['linetoken']
    #     msg1 = line_tokenget[1]['linemsg']
    #     line_notify(msg1,id)
    # #MessageNo.3
    # if device_batch_read[2] == 1:
    #     id= line_tokenget[2]['linetoken']
    #     msg1 = line_tokenget[2]['linemsg']
    #     line_notify(msg1,id)
    # #MessageNo.4
    # if device_batch_read[3] == 1:
    #     id= line_tokenget[3]['linetoken']
    #     msg1 = line_tokenget[3]['linemsg']
    #     line_notify(msg1,id)
    # #MessageNo.5
    # if device_batch_read[4] == 1:
    #     id= line_tokenget[4]['linetoken']
    #     msg1 = line_tokenget[4]['linemsg']
    #     line_notify(msg1,id)
    # #MessageNo.6
    # if device_batch_read[5] == 1:
    #     id= line_tokenget[5]['linetoken']
    #     msg1 = line_tokenget[5]['linemsg']
    #     line_notify(msg1,id)
    # #MessageNo.7
    # if device_batch_read[6] == 1:
    #     id= line_tokenget[6]['linetoken']
    #     msg1 = line_tokenget[6]['linemsg']
    #     line_notify(msg1,id)
    # #MessageNo.8
    # if device_batch_read[7] == 1:
    #     id= line_tokenget[7]['linetoken']
    #     msg1 = line_tokenget[7]['linemsg']
    #     line_notify(msg1,id)
    # #MessageNo.9
    # if device_batch_read[8] == 1:
    #     id= line_tokenget[8]['linetoken']
    #     msg1 = line_tokenget[8]['linemsg']
    #     line_notify(msg1,id)
    # #MessageNo.10
    # if device_batch_read[9] == 1:
    #     id= line_tokenget[9]['linetoken']
    #     msg1 = line_tokenget[9]['linemsg']
    #     line_notify(msg1,id)

    # '''MC01 M10011-M10020'''
    # #MessageNo.11
    # if device_batch_read[10] == 1:
    #     id= line_tokenget[10]['linetoken']
    #     msg1 = line_tokenget[10]['linemsg']
    #     line_notify(msg1,id)
    # #MessageNo.12
    # if device_batch_read[11] == 1:
    #     id= line_tokenget[11]['linetoken']
    #     msg1 = line_tokenget[11]['linemsg']
    #     line_notify(msg1,id)
    # #MessageNo.13
    # if device_batch_read[12] == 1:
    #     id= line_tokenget[12]['linetoken']
    #     msg1 = line_tokenget[12]['linemsg']
    #     line_notify(msg1,id)
    # #MessageNo.14
    # if device_batch_read[13] == 1:
    #     id= line_tokenget[13]['linetoken']
    #     msg1 = line_tokenget[13]['linemsg']
    #     line_notify(msg1,id)
    # #MessageNo.15
    # if device_batch_read[14] == 1:
    #     id= line_tokenget[14]['linetoken']
    #     msg1 = line_tokenget[14]['linemsg']
    #     line_notify(msg1,id)
    # #MessageNo.16
    # if device_batch_read[15] == 1:
    #     id= line_tokenget[15]['linetoken']
    #     msg1 = line_tokenget[15]['linemsg']
    #     line_notify(msg1,id)
    # #MessageNo.17
    # if device_batch_read[16] == 1:
    #     id= line_tokenget[16]['linetoken']
    #     msg1 = line_tokenget[16]['linemsg']
    #     line_notify(msg1,id)
    # #MessageNo.18
    # if device_batch_read[17] == 1:
    #     id= line_tokenget[17]['linetoken']
    #     msg1 = line_tokenget[17]['linemsg']
    #     line_notify(msg1,id)
    # #MessageNo.19
    # if device_batch_read[18] == 1:
    #     id= line_tokenget[18]['linetoken']
    #     msg1 = line_tokenget[18]['linemsg']
    #     line_notify(msg1,id)
    # #MessageNo.20
    # if device_batch_read[19] == 1:
    #     id= line_tokenget[19]['linetoken']
    #     msg1 = line_tokenget[19]['linemsg']
    #     line_notify(msg1,id)

    # '''MC01 M10021-M10030'''
    # #MessageNo.21
    # if device_batch_read[20] == 1:
    #     id= line_tokenget[20]['linetoken']
    #     msg1 = line_tokenget[20]['linemsg']
    #     line_notify(msg1,id)
    # #MessageNo.22
    # if device_batch_read[21] == 1:
    #     id= line_tokenget[21]['linetoken']
    #     msg1 = line_tokenget[21]['linemsg']
    #     line_notify(msg1,id)
    # #MessageNo.23
    # if device_batch_read[22] == 1:
    #     id= line_tokenget[22]['linetoken']
    #     msg1 = line_tokenget[22]['linemsg']
    #     line_notify(msg1,id)
    # #MessageNo.24
    # if device_batch_read[23] == 1:
    #     id= line_tokenget[23]['linetoken']
    #     msg1 = line_tokenget[23]['linemsg']
    #     line_notify(msg1,id)
    # #MessageNo.25
    # if device_batch_read[24] == 1:
    #     id= line_tokenget[24]['linetoken']
    #     msg1 = line_tokenget[24]['linemsg']
    #     line_notify(msg1,id)
    # #MessageNo.26
    # if device_batch_read[25] == 1:
    #     id= line_tokenget[25]['linetoken']
    #     msg1 = line_tokenget[25]['linemsg']
    #     line_notify(msg1,id)
    # #MessageNo.27
    # if device_batch_read[26] == 1:
    #     id= line_tokenget[26]['linetoken']
    #     msg1 = line_tokenget[26]['linemsg']
    #     line_notify(msg1,id)
    # #MessageNo.28
    # if device_batch_read[27] == 1:
    #     id= line_tokenget[27]['linetoken']
    #     msg1 = line_tokenget[27]['linemsg']
    #     line_notify(msg1,id)
    # #MessageNo.29
    # if device_batch_read[28] == 1:
    #     id= line_tokenget[28]['linetoken']
    #     msg1 = line_tokenget[28]['linemsg']
    #     line_notify(msg1,id)
    # #MessageNo.30
    # if device_batch_read[29] == 1:
    #     id= line_tokenget[29]['linetoken']
    #     msg1 = line_tokenget[29]['linemsg']
    #     line_notify(msg1,id)

    # '''MC01 M10031-M10040'''
    # #MessageNo.31
    # if device_batch_read[30] == 1:
    #     id= line_tokenget[30]['linetoken']
    #     msg1 = line_tokenget[30]['linemsg']
    #     line_notify(msg1,id)
    # #MessageNo.32
    # if device_batch_read[31] == 1:
    #     id= line_tokenget[31]['linetoken']
    #     msg1 = line_tokenget[31]['linemsg']
    #     line_notify(msg1,id)
    # #MessageNo.33
    # if device_batch_read[32] == 1:
    #     id= line_tokenget[32]['linetoken']
    #     msg1 = line_tokenget[32]['linemsg']
    #     line_notify(msg1,id)
    # #MessageNo.34
    # if device_batch_read[33] == 1:
    #     id= line_tokenget[33]['linetoken']
    #     msg1 = line_tokenget[33]['linemsg']
    #     line_notify(msg1,id)
    # #MessageNo.35
    # if device_batch_read[34] == 1:
    #     id= line_tokenget[34]['linetoken']
    #     msg1 = line_tokenget[34]['linemsg']
    #     line_notify(msg1,id)
    # #MessageNo.36
    # if device_batch_read[35] == 1:
    #     id= line_tokenget[35]['linetoken']
    #     msg1 = line_tokenget[35]['linemsg']
    #     line_notify(msg1,id)
    # #MessageNo.37
    # if device_batch_read[36] == 1:
    #     id= line_tokenget[36]['linetoken']
    #     msg1 = line_tokenget[36]['linemsg']
    #     line_notify(msg1,id)
    # #MessageNo.38
    # if device_batch_read[37] == 1:
    #     id= line_tokenget[37]['linetoken']
    #     msg1 = line_tokenget[37]['linemsg']
    #     line_notify(msg1,id)
    # #MessageNo.39
    # if device_batch_read[38] == 1:
    #     id= line_tokenget[38]['linetoken']
    #     msg1 = line_tokenget[38]['linemsg']
    #     line_notify(msg1,id)
    # #MessageNo.40
    # if device_batch_read[39] == 1:
    #     id= line_tokenget[39]['linetoken']
    #     msg1 = line_tokenget[39]['linemsg']
    #     line_notify(msg1,id)

    # '''MC01 M10041-M10050'''
    # #MessageNo.41
    # if device_batch_read[40] == 1:
    #     id= line_tokenget[40]['linetoken']
    #     msg1 = line_tokenget[40]['linemsg']
    #     line_notify(msg1,id)
    # #MessageNo.42
    # if device_batch_read[41] == 1:
    #     id= line_tokenget[41]['linetoken']
    #     msg1 = line_tokenget[41]['linemsg']
    #     line_notify(msg1,id)
    # #MessageNo.43
    # if device_batch_read[42] == 1:
    #     id= line_tokenget[42]['linetoken']
    #     msg1 = line_tokenget[42]['linemsg']
    #     line_notify(msg1,id)
    # #MessageNo.44
    # if device_batch_read[43] == 1:
    #     id= line_tokenget[43]['linetoken']
    #     msg1 = line_tokenget[43]['linemsg']
    #     line_notify(msg1,id)
    # #MessageNo.45
    # if device_batch_read[44] == 1:
    #     id= line_tokenget[44]['linetoken']
    #     msg1 = line_tokenget[44]['linemsg']
    #     line_notify(msg1,id)
    # #MessageNo.46
    # if device_batch_read[45] == 1:
    #     id= line_tokenget[45]['linetoken']
    #     msg1 = line_tokenget[45]['linemsg']
    #     line_notify(msg1,id)
    # #MessageNo.47
    # if device_batch_read[46] == 1:
    #     id= line_tokenget[46]['linetoken']
    #     msg1 = line_tokenget[46]['linemsg']
    #     line_notify(msg1,id)
    # #MessageNo.48
    # if device_batch_read[47] == 1:
    #     id= line_tokenget[47]['linetoken']
    #     msg1 = line_tokenget[47]['linemsg']
    #     line_notify(msg1,id)
    # #MessageNo.49
    # if device_batch_read[48] == 1:
    #     id= line_tokenget[48]['linetoken']
    #     msg1 = line_tokenget[48]['linemsg']
    #     line_notify(msg1,id)
    # #MessageNo.50
    # if device_batch_read[49] == 1:
    #     id= line_tokenget[49]['linetoken']
    #     msg1 = line_tokenget[49]['linemsg']
    #     line_notify(msg1,id)


# def line_notify(message,id):

#     # tokendb = Linemessage.objects.get(id=id).linetoken
#     tokendb = id
#     #print(tokendb)
#     url = 'https://notify-api.line.me/api/notify'
#     token1 = tokendb
#     headers1 = {'content-type':'application/x-www-form-urlencoded',
#                 'Authorization':'Bearer '+token1}
#     msg1 = message
#     r = requests.post(url, headers=headers1 , data = {'message':msg1}) 
#     print(r.text)
    

if __name__ == '__main__':
    app.run(host='0.0.0.0',debug=True)
    #plc_notify()
    